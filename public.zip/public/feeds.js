const fetchFeeds = () => {
    fetch('./../app/get_all_rss_feeds.php')
    .then((data) => data.json())
    .then(result => {

        let dato = document.getElementById('dato');
        dato.innerHTML = `<p>${result[0].title}</p>`
  
        console.log(result[0].title);
        console.log(result[0].description);
        console.log(result[0].news);
        console.log(result[0].news[0].title);
        console.log(result[0].news[1].title);
        console.log(result[0].news[2].title);
    });
}

fetchFeeds()