const id = sessionStorage.getItem('id');

const fetchFeeds = () => {
    fetch("./../app/get_all_rss_feeds.php")
    .then((data) => data.json())
    .then((result) => {
        for (let j = 0; j < result[id].news.length; j++){
             insertarCajasNews(result[id].news[j].title, result[id].news[j].description, result[id].news[j].categories,result[id].news[j].pubDate, result[id].news[j].url);
        }
    });
};

function insertarCajasNews(title, description, categories,pubDate,url){
    let cajaNews = `
    <div class="col-md-4 mt-2">
        <div class="card text-dark bg-light mb-3 text-center rounded-top">
            <div class="card-header text-white rounded-bottom" style="background:#4f6d7a">
                ${title}
            </div>
            <div class="card-body">
                <p class="card-text" style="overflow:hidden">${description} </p>
                <p class="card-text">${categories}</p>
                <footer><p class="card-text mb-3">${pubDate.date}</p></footer>
                <a class="btn btn-outline-dark" href="${url}">Check the entire news</a>
            </div>
        </div>
    </div>`
    const rowNews = document.getElementById('news');
    rowNews.insertAdjacentHTML('beforeend', cajaNews);
}

fetchFeeds();
